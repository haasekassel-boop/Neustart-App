NEUSTART – persönliche iPhone-PWA (Testversion)

INHALT
- Persönliches Tagebuch (Anbieter, Spiel, Datum, Einsatz, Auszahlung)
- Automatische Berechnung des Ergebnisses
- Übersicht und Top-10-Spiele
- Spielfreie Tage seit dem letzten dokumentierten Spieleintrag
- 90-Tage-Testanzeige ab erstem Start
- JSON-Sicherung exportieren und wieder importieren
- Offline-Grundfunktion nach dem ersten Laden

WICHTIG
Diese Version speichert die Einträge lokal im Browser (IndexedDB) auf dem jeweiligen Gerät. Es gibt keine Anmeldung, keinen Server und keine automatische Übertragung an andere Personen. Löschen der Website-Daten, Zurücksetzen des Geräts oder Verlust des Geräts kann Datenverlust verursachen. Regelmäßig über Statistik > Daten exportieren sichern.

INSTALLATION AUF IPHONE
1. Die Dateien müssen über eine HTTPS-Adresse erreichbar sein. Eine normale lokale Datei oder ein Link auf eine ZIP-Datei reicht nicht für die PWA-Installation.
2. Die Dateien in einen kostenlosen statischen Webspace hochladen (z. B. GitHub Pages; dafür ist ein kostenloses GitHub-Konto nötig).
3. Die HTTPS-Adresse in Safari öffnen.
4. Teilen > Zum Home-Bildschirm > Hinzufügen.

Diese ZIP-Datei ist noch nicht veröffentlicht oder auf deinem iPhone installiert. Für eine Veröffentlichung ist ein Hosting-Schritt erforderlich. Ein kostenloser statischer Anbieter kann dafür ausreichen; ein eigener kostenpflichtiger Server ist nicht nötig.
